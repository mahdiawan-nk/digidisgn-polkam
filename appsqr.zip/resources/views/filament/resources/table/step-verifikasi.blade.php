{{-- <div class="p-6 bg-gray-100"> --}}
<div class="space-y-4 p-3">
    <!-- In Process -->
    @if ($getState() != null)
        @foreach ($getState() as $steps)
            @php
                $stepsStatusColor = match ($steps->status) {
                    'pending' => 'bg-yellow-400 text-yellow-800',
                    'approved' => 'bg-green-100 text-green-800',
                    'rejected' => 'bg-red-100 text-red-800',
                    default => 'bg-blue-100 text-blue-800',
                };
            @endphp
            <div class="flex items-center space-x-3">
                <span class="text-gray-600 text-xs">{{ $steps->role_required }}:</span>
                <span class="{{ $stepsStatusColor }} text-xs font-semibold px-2 py-1 rounded">
                    {{ $steps->status }}
                </span>
                {{-- <span class="text-gray-500 text-sm">14 Jan 2025, 09:00 AM</span> --}}
            </div>
        @endforeach

    @endif


    {{-- <!-- In Verification -->
        <div class="flex items-center space-x-3">
            <span class="text-gray-600 font-medium">Step 2:</span>
            <span class="bg-blue-100 text-blue-800 text-sm font-semibold px-3 py-1 rounded-full">
                In Verification
            </span>
            <span class="text-gray-500 text-sm">14 Jan 2025, 10:30 AM</span>
        </div>

        <!-- In Validation -->
        <div class="flex items-center space-x-3">
            <span class="text-gray-600 font-medium">Step 3:</span>
            <span class="bg-yellow-100 text-yellow-800 text-sm font-semibold px-3 py-1 rounded-full">
                In Validation
            </span>
            <span class="text-gray-500 text-sm">14 Jan 2025, 01:00 PM</span>
        </div>

        <!-- Returned -->
        <div class="flex items-center space-x-3">
            <span class="text-gray-600 font-medium">Step 4:</span>
            <span class="bg-red-100 text-red-800 text-sm font-semibold px-3 py-1 rounded-full">
                Returned
            </span>
            <span class="text-gray-500 text-sm">14 Jan 2025, 03:15 PM</span>
        </div>

        <!-- Finished -->
        <div class="flex items-center space-x-3">
            <span class="text-gray-600 font-medium">Step 5:</span>
            <span class="bg-green-100 text-green-800 text-sm font-semibold px-3 py-1 rounded-full">
                Finished
            </span>
            <span class="text-gray-500 text-sm">14 Jan 2025, 05:00 PM</span>
        </div> --}}
</div>
{{-- </div> --}}

<x-filament-panels::page>
    @livewire('setting-pdf')
</x-filament-panels::page>

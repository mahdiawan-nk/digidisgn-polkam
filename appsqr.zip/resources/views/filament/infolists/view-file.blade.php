
<iframe src="{{ asset('storage/' . $record->file_surat) }}" width="100%" height="600px" frameborder="0"></iframe>
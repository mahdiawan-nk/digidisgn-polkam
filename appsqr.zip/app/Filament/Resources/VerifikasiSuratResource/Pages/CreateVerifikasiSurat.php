<?php

namespace App\Filament\Resources\VerifikasiSuratResource\Pages;

use App\Filament\Resources\VerifikasiSuratResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateVerifikasiSurat extends CreateRecord
{
    protected static string $resource = VerifikasiSuratResource::class;
}

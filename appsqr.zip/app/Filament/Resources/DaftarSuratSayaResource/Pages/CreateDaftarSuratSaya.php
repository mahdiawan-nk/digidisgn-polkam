<?php

namespace App\Filament\Resources\DaftarSuratSayaResource\Pages;

use App\Filament\Resources\DaftarSuratSayaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDaftarSuratSaya extends CreateRecord
{
    protected static string $resource = DaftarSuratSayaResource::class;
}

<?php

namespace App\Filament\Resources\PengajuanSuratResource\Pages;

use App\Filament\Resources\PengajuanSuratResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;
use App\Filament\Resources\DaftarSuratSayaResource as SuratResource;
use Illuminate\Database\Eloquent\Model;
use App\Models\SuratValidationStep;
use App\Models\SuratValidationLog;
class EditPengajuanSurat extends EditRecord
{
    protected static string $resource = PengajuanSuratResource::class;

    protected function getHeaderActions(): array
    {
        return [
            // Actions\DeleteAction::make(),
        ];
    }

    protected function getRedirectUrl(): string
    {
        return SuratResource::getUrl('index');
    }

    protected function handleRecordUpdate(Model $record, array $data): Model
    {   
        $data['status_pengajuan'] = 're-submited';
        $record->update($data);

        self::updateSteps($record->id);
        self::createLogs($record);
        return $record;
    }

    public static function updateSteps($surat_id){
        $steps = SuratValidationStep::where('surat_id', $surat_id)->update([
            'status' => 'pending',
        ]);
        
    }
    public static function createLogs($surat){
        SuratValidationLog::create([
            'surat_id' => $surat->id,
            'user_id' => auth()->user()->id,
            'validation_step' => '1',
            'action' => 're-submited',
            'note' => 'Mengajukan Ulang Surat',
        ]);
    }
}

<?php

namespace App\Filament\Resources\DataJabatanResource\Pages;

use App\Filament\Resources\DataJabatanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDataJabatan extends CreateRecord
{
    protected static string $resource = DataJabatanResource::class;
}

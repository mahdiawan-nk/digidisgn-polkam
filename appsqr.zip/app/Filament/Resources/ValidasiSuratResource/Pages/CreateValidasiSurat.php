<?php

namespace App\Filament\Resources\ValidasiSuratResource\Pages;

use App\Filament\Resources\ValidasiSuratResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateValidasiSurat extends CreateRecord
{
    protected static string $resource = ValidasiSuratResource::class;
}

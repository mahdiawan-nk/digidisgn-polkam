<?php

namespace App\Filament\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use App\Models\User;
use App\Models\Surat;

class StatsOverview extends BaseWidget
{
    protected function getColumns(): int
    {
        if (auth()->user()->hasRole('super-admin')) {
            return 4;
        } else {
            return 3;
        }
    }
    protected function getStats(): array
    {
        return [
            Stat::make(
                'Surat Diajukan',
                static::countSuratDiajukan(),
            ),
            Stat::make(
                'Surat Disetujui',
                static::countSuratDisetujui(),
            ),
            Stat::make(
                'Surat Ditolak',
                static::countSuratDitolak(),
            ),
            Stat::make(
                'Pengguna',
                User::count(),
            )->extraAttributes([
                'class' => auth()->user()->hasRole('super-admin') ? 'block' : 'hidden',
            ]),

        ];
    }

    public static function countSuratDiajukan()
    {
        $user = auth()->user();
        $dataCount = 0;

        return $dataCount;
    }

    public static function countSuratDisetujui()
    {
        $user = auth()->user();
        $dataCount = 0;

        return $dataCount;
    }

    public static function countSuratDitolak()
    {
        $user = auth()->user();
        $dataCount = 0;
        
        return $dataCount;
    }
}

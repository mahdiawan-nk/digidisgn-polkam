<?php if (isset($component)) { $__componentOriginalb525200bfa976483b4eaa0b7685c6e24 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-widgets::components.widget','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-widgets::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white p-6 rounded-lg shadow-md">
        <!-- User Avatar -->
        <div class="flex flex-col items-center">
            <img src="<?php echo e($avatar); ?>" alt="User Avatar" class="h-24 w-24 rounded-full object-cover mb-4">
            <!-- User Info -->
            <h3 class="text-xl font-semibold text-gray-800"><?php echo e($name); ?></h3>
            <p class="text-sm text-gray-600"><?php echo e($email); ?></p>
            <p class="text-sm text-gray-600"><?php echo e($position); ?></p>
            <p class="text-sm text-gray-600"><?php echo e($roles[0]); ?></p>
        </div>
        <!-- Welcome Message and Date -->
        <div class="mt-6 text-center">
            <h1 class="text-xl font-semibold text-gray-800">Selamat Datang di Aplikasi DigSign</h1>
            <p class="text-sm text-gray-600"><?php echo e(now()->format('l, d F Y')); ?></p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $attributes = $__attributesOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__attributesOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24)): ?>
<?php $component = $__componentOriginalb525200bfa976483b4eaa0b7685c6e24; ?>
<?php unset($__componentOriginalb525200bfa976483b4eaa0b7685c6e24); ?>
<?php endif; ?>
<?php /**PATH P:\PROJECT FREELANCE\POLKAM\appsqr\resources\views/filament/widgets/user-profile-widget.blade.php ENDPATH**/ ?>
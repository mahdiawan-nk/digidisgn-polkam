
<div class="space-y-4 p-3">
    <!-- In Process -->
    <!--[if BLOCK]><![endif]--><?php if($getState() != null): ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $getState(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $steps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $stepsStatusColor = match ($steps->status) {
                    'pending' => 'bg-yellow-400 text-yellow-800',
                    'approved' => 'bg-green-100 text-green-800',
                    'rejected' => 'bg-red-100 text-red-800',
                    default => 'bg-blue-100 text-blue-800',
                };
            ?>
            <div class="flex items-center space-x-3">
                <span class="text-gray-600 text-xs"><?php echo e($steps->role_required); ?>:</span>
                <span class="<?php echo e($stepsStatusColor); ?> text-xs font-semibold px-2 py-1 rounded">
                    <?php echo e($steps->status); ?>

                </span>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


    
</div>

<?php /**PATH P:\PROJECT FREELANCE\POLKAM\appsqr\resources\views/filament/resources/table/step-verifikasi.blade.php ENDPATH**/ ?>
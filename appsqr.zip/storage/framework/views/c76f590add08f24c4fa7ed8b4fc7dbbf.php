<div class="relative overflow-x-auto shadow-md sm:rounded-lg">
    <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
        <caption
            class="p-5 text-lg font-semibold text-left rtl:text-right text-gray-900 bg-white dark:text-white dark:bg-gray-800">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Activity Logs</h3>
        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                <th scope="col" class="px-6 py-3">
                    User
                </th>
                <th scope="col" class="px-6 py-3">
                    Action
                </th>
                <th scope="col" class="px-6 py-3">
                    logs
                </th>
                <th scope="col" class="px-6 py-3">
                    Time
                </th>
                <th scope="col" class="px-6 py-3">
                    tanggal
                </th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $record->validation_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 border-gray-200">
                    <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                        <?php echo e($log->user->name); ?>

                    </th>
                    <td class="px-6 py-4">
                        <?php echo e($log->action); ?>

                    </td>
                    <td class="px-6 py-4">
                        <?php echo e($log->note); ?>

                    </td>
                    <td class="px-6 py-4">
                        <?php echo e(\Carbon\Carbon::parse($log->created_at)->format('H:i:s')); ?>

                    </td>
                    <td class="px-6 py-4">
                        <?php echo e(\Carbon\Carbon::parse($log->created_at)->format('d-m-Y')); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->


        </tbody>
    </table>
</div>
<?php /**PATH P:\PROJECT FREELANCE\POLKAM\appsqr\resources\views/filament/infolists/logs-activity.blade.php ENDPATH**/ ?>
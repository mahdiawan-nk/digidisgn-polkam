<script src="https://cdn.tailwindcss.com"></script>
<div class="flex items-center space-x-2">
    <!-- Logo -->
    <img src="<?php echo e(asset('logo.png')); ?>" alt="Logo" class="h-12 w-12 object-contain">
    <!-- Brand Name -->
    <span class="text-xl font-bold text-gray-800">DigSign</span>
</div>
<?php /**PATH P:\PROJECT FREELANCE\POLKAM\appsqr\resources\views/components/brandlogo.blade.php ENDPATH**/ ?>